<!DOCTYPE html>
<html>
<head><title>Digital Business Card</title>
    <meta charset=utf-8>
    <meta name=description content="Digital Business Card">
    <meta name=format-detection content="telephone=no">
    <meta name=msapplication-tap-highlight content=no>
    <meta name=viewport content="user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1,width=device-width">
    <?php echo $__env->yieldPushContent('meta'); ?>
    <link rel=icon type=image/png sizes=128x128 href=/icons/favicon-128x128.png>
    <link rel=icon type=image/png sizes=96x96 href=/icons/favicon-96x96.png>
    <link rel=icon type=image/png sizes=32x32 href=/icons/favicon-32x32.png>
    <link rel=icon type=image/png sizes=16x16 href=/icons/favicon-16x16.png>
    <link rel=icon type=image/ico href=/favicon.ico>
    <script>
        <?php echo $__env->yieldPushContent('script'); ?>
    </script>
    <script type="module" crossorigin src="/assets/index-7HjL0rFh.js"></script>
    <link rel="stylesheet" crossorigin href="/assets/index-BxPdo39T.css">
</head>
<body>
<div id=q-app></div>
</body>
</html>
<?php /**PATH F:\DIGITALBUSINESSCARD\Backend\packages\firumon\digital-business-card\src/../resources/views/template/layout.blade.php ENDPATH**/ ?>