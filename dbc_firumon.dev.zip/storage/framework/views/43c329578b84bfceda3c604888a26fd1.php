<?php $__env->startSection('base'); ?><base href="http://localhost:9000">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vite'); ?><script type="module" src="/@vite/client"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','Digital Business Card'); ?>
<?php $__env->startPush('meta'); ?><meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('append_body'); ?>
    <script type="module" src="/.quasar/dev-spa/client-entry.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make(config('dbc.development') === "1" ? 'dbc::template.layout_dev' : 'dbc::template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\DIGITALBUSINESSCARD\Backend\packages\firumon\digital-business-card\src/../resources/views/login.blade.php ENDPATH**/ ?>