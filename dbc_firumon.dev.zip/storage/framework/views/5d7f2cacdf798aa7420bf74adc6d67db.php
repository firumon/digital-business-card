
<!DOCTYPE html>
<html>
<head>
    <base href="http://localhost:9000">
    <script type="module" src="/@vite/client"></script>

    <title>Digital Business Card</title>

    <meta charset="utf-8">
    <meta name="description" content="Digital Business Card">
    <meta name="format-detection" content="telephone=no">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">

    <link rel="icon" type="image/png" sizes="128x128" href="/icons/favicon-128x128.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/icons/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/icons/favicon-16x16.png">
    <link rel="icon" type="image/ico" href="/favicon.ico">

    <script>const __DATA = {theme:{brand:{primary:'#222528',secondary:'#E6BE21',accent:'',dark:'',positive:'',negative:'',info:'',warning:''},color:{primary:'#FFFFFF',secondary:'#000000',accent:'',dark:'',positive:'',negative:'',info:'',warning:''}},company:{name:'',logo:{url:'./logos/template/EliteCard.png',width:'875px',height:'619px'},individuals:['firose'],layout:'',},layout:{header:false,logo_span:14,photo_span:20,actions:[{label:'Book An Appointment'},{label:'Schedule A consultation'},{label:'About Us',home:true}],individual:['full_name','designation','profile_photo','background_profile','mobile_number','office_number','email_address','website','whatsapp','instagram','facebook','messenger'],mandatory:['full_name','designation','profile_photo','background_profile','mobile_number','email_address'],contacts:['mobile_number','office_number','email_address','website','whatsapp','instagram','facebook','messenger']},individuals:{firose:{full_name:'Firose Hussain','designation':'Full Stack Developer','profile_photo':'https://scontent.fcok6-1.fna.fbcdn.net/v/t39.30808-1/467522586_10230519237877198_4546831028559208705_n.jpg?stp=dst-jpg_s200x200_tt6&_nc_cat=105&ccb=1-7&_nc_sid=e99d92&_nc_ohc=RdDsZRx4uM8Q7kNvgGGiGT4&_nc_oc=AdjA0K3a8cCpLNEZZGzcmYb-jaYoZex6hGbccJQIm1Af5pLS1qjTkTkex_1Uw0FnPMCVoUg5kNpB1YUZVnh85SaS&_nc_zt=24&_nc_ht=scontent.fcok6-1.fna&_nc_gid=ATplfPFZy499yYKP3RrGdpc&oh=00_AYD3aiA1_xShQduZi3HZaAwnta6nLNz1MHTZsGMfTaI7Sg&oe=67A7D318',background_profile:'https://i.ibb.co/BHcVFWqy/4V2A5782.jpg',mobile_number:'9495155550',email_address:'me@firumon.com',whatsapp:'919495155550',messenger:'firose.hussain'}}}</script>
</head>
<body>
<div id="q-app"></div><script type="module" src="/.quasar/dev-spa/client-entry.js"></script>
</body>
</html>
<?php /**PATH F:\DIGITALBUSINESSCARD\Backend\resources\views/app.blade.php ENDPATH**/ ?>