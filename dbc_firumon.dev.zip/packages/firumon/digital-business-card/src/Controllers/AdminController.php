<?php

namespace Firumon\DigitalBusinessCard\Controllers;

use App\Http\Controllers\Controller;
use Firumon\DigitalBusinessCard\Models\Company;
use Illuminate\Http\Request;
use Illuminate\View\View;

class AdminController extends Controller
{

}
