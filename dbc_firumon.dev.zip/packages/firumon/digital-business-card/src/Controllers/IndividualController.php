<?php

namespace Firumon\DigitalBusinessCard\Controllers;

use App\Http\Controllers\Controller;
use Firumon\DigitalBusinessCard\Models\Attr;
use Firumon\DigitalBusinessCard\Models\Company;
use Firumon\DigitalBusinessCard\Models\Individual;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class IndividualController extends Controller
{
    public static function individual_data($code): Model {
        return Individual::with(['Attrs','Company'])->where('code',$code)->firstOrFail();
    }

    public static function flatten($individual): array {
        $flatten = $individual->only(['code','name','designation']);
        $individual->Attrs->each(function($attr)use(&$flatten){ $flatten[$attr->attr] = $attr->value; });
        return $flatten;
    }

    public function individual(Request $request){
        return ($request->filled('code') && $request->input('code') !== 'NEW')
            ? $this->update_individual($request->input('individual'))
            : $this->create_individual($request->input('individual'));
    }

    public function update_individual($individual): array {
        $code = $individual['code']; $name = $individual['name']; $designation = $individual['designation'];
        $Individual = Individual::where('code',$code)->first(); $individual_id = $Individual->id;
        $Individual->update(compact('name','designation'));
        foreach ($individual as $attr => $value){
            if(in_array($attr,Individual::$fields)) continue;
            Attr::updateOrCreate(compact('individual_id','attr'),compact('value'));
        }
        return self::flatten($Individual->fresh(['Attrs']));
    }

    public function create_individual($individual): array {
        $company_code = request()->user()->Company->code; $company_id = request()->user()->Company->id;
        $code = $company_code . Individual::NextIndividualNumber($company_id);
        $name = $individual['name']; $designation = $individual['designation'];
        $Individual = Individual::create(compact('code','name','designation','company_id'));
        $Attrs = [];
        foreach ($individual as $attr => $value){
            if(in_array($attr,Individual::$fields)) continue;
            $Attrs[] = new Attr(compact('attr','value'));
        }
        if(!empty($Attrs)) $Individual->Attrs()->saveMany($Attrs);
        return self::flatten($Individual->fresh(['Attrs']));
    }
}
