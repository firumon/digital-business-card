<?php

namespace Firumon\DigitalBusinessCard\Controllers;

use App\Http\Controllers\Controller;
use Firumon\DigitalBusinessCard\Models\Company;
use Illuminate\Database\Eloquent\Model;

class CompanyController extends Controller
{
    public static function company_data($code): Model {
        return Company::where('code',$code)->with(['Logo','Actions','Layout.Master.Attrs','Params','Individuals.Attrs'])->firstOrFail();
    }

    public static function theme_from_company_layout($layout): array {
        return $layout->only(['brand','color']);
    }


}
