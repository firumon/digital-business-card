<?php

namespace Firumon\DigitalBusinessCard\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Company extends Model
{
    protected $guarded = [];
    protected $hidden = ['created_at','updated_at'];


    public function Logo(): HasOne { return $this->hasOne(Logo::class)->withDefault(['url' => 'https://i.postimg.cc/L6YPvjQy/NoImage.jpg','width' => '320px','height' => '320px']); }
    public function Layout(): HasOne { return $this->hasOne(Layout::class); }
    public function Params(): HasMany { return $this->hasMany(Param::class); }
    public function Actions(): HasMany { return $this->hasMany(Action::class); }
    public function Individuals(): HasMany { return $this->hasMany(Individual::class); }
    public function Admin(): HasOne { return $this->hasOne(User::class); }

    public static function CompanyId($company_code): int {
        if(!$company_code) abort(403);
        return self::where('code',$company_code)->first()->id;
    }
}
