<?php

namespace Firumon\DigitalBusinessCard\Models;

use Illuminate\Database\Eloquent\Model;

class LayoutAttr extends Model
{
    protected $guarded = [];
    protected $hidden = ['created_at','updated_at'];

    protected $casts = ['image' => 'bool', 'mandatory' => 'bool', 'contact' => 'bool', 'individual' => 'bool'];
}
