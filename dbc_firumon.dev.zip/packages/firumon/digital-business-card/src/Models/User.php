<?php

namespace Firumon\DigitalBusinessCard\Models;

use App\Models\User as BaseUser;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class User extends BaseUser
{
    protected $guarded = [];
    protected $hidden = ['password'];
    protected $casts = ['password' => 'hashed', 'admin' => 'bool'];
    protected $with = ['Company.Layout'];

    public function Company(): BelongsTo { return $this->belongsTo(Company::class); }
}
