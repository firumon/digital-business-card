<?php

namespace Firumon\DigitalBusinessCard\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

class Individual extends Model
{
    protected $guarded = [];
    protected $hidden = ['created_at','updated_at'];
    protected $digits = 4;
    public static $fields = ['code','name','designation'];

    public function Attrs(): HasMany { return $this->hasMany(Attr::class); }
    public function Company(): BelongsTo { return $this->belongsTo(Company::class); }

    public static function NextIndividualNumber($company_id): string {
        $lastIndividualCode = self::where('company_id',$company_id)->latest('id')->first()?->code ?? "00";
        $lastIndividualNum = intval(Str::of($lastIndividualCode)->replaceMatches('/^[A-Za-z]+/','')->value());
        return Str::of($lastIndividualNum+1)->padLeft(4,'0')->value();
    }
}
