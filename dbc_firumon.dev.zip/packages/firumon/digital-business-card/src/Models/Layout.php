<?php

namespace Firumon\DigitalBusinessCard\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Layout extends Model
{
    protected $guarded = [];
    protected $hidden = ['created_at','updated_at'];
    protected $casts = ['brand' => 'array','color' => 'array'];

    public function Master(): BelongsTo {
        return $this->belongsTo(LayoutMaster::class,'layout_master_id','id');
    }
}
