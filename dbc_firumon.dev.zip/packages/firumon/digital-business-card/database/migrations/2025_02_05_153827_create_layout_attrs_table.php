<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('layout_attrs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('layout_master_id')->index();
            $table->string('attr')->nullable();
            $table->binary('image',1)->default(0);
            $table->binary('mandatory',1)->default(0);
            $table->binary('individual',1)->default(0);
            $table->binary('contact',1)->default(0);
            $table->text('description')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('attrs');
    }
};
