<?php

use Illuminate\Support\Facades\Route;
use Firumon\DigitalBusinessCard\Controllers\RouteController;
use Firumon\DigitalBusinessCard\Controllers\IndividualController;
use Firumon\DigitalBusinessCard\Controllers\SettingController;
use Firumon\DigitalBusinessCard\Controllers\AuthController;
use Firumon\DigitalBusinessCard\Controllers\AdminApiController;
use Firumon\DigitalBusinessCard\Middleware\AuthAdmin;

Route::middleware(['web'])->group(function(){
    Route::middleware(['auth'])->group(function(){
        Route::get('{item}',[RouteController::class,'company_admin'])->whereIn('item',['individuals','settings']);
        Route::post('individual',[IndividualController::class,'individual'])->name('company_admin');
        Route::post('setting',[SettingController::class,'setting']);
        Route::view('admin','dbc::admin')->name('admin')->middleware([AuthAdmin::class]);
        Route::get('logout',[AuthController::class,'logout'])->name('logout');
        Route::group([
            'prefix' => '/admin/api',
            'controller' => AdminApiController::class,
            'middleware' => AuthAdmin::class
        ],function(){
            Route::prefix('{company_code}')->group(function(){
                Route::post('individuals_urls','individuals_urls');
            });
        });
    });
    Route::get('/',[RouteController::class,'app_view_company']);
    Route::view('/login','dbc::login')->name('login');
    Route::post('/login',[AuthController::class,'login']);
    Route::get('/{code}',[RouteController::class,'app_view_individual']);
});
