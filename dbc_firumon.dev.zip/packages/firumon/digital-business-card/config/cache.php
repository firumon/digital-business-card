<?php

return [
    'default' => 'file',
];
