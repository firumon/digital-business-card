<?php

return [
    'development' => env('DEV',0),
];
