<?php

return [
    App\Providers\AppServiceProvider::class,
    \Firumon\DigitalBusinessCard\DigitalBusinessCardServiceProvider::class,
];
