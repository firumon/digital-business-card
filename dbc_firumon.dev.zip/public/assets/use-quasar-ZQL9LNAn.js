import{y as a,a7 as r}from"./index-DpVdVZbR.js";function u(){return a(r)}export{u};
