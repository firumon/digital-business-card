import{y as a,a7 as r}from"./index-7HjL0rFh.js";function u(){return a(r)}export{u};
